import React from 'react';
import {StoreCreditVendorList} from '../CorporateCreditList';

const StoreCreditVendors = (props) => {
    return <StoreCreditVendorList {...props} />;
};

export {StoreCreditVendors};

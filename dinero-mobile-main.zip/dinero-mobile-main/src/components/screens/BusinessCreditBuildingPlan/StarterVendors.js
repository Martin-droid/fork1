import React from 'react';

import {StarterVendorList} from '../CorporateCreditList';

const StarterVendors = (props) => {
    return <StarterVendorList {...props} />;
};

export {StarterVendors};
